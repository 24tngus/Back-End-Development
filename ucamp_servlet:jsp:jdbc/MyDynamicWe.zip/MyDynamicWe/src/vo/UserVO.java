package vo;

public class UserVO {
	private int id;
	private String UserId;
	private String name;
	private String gender;
	private String city;
	
	public UserVO() { // �⺻ ������
		
	}
	public UserVO(int id, String userId, String name, String gender, String city) { // argument ���� �޴� ������ 
		super();
		this.id = id;
		UserId = userId;
		this.name = name;
		this.gender = gender;
		this.city = city;
	}
	public int getId() {
		return id;
	}
	public String getUserId() {
		return UserId;
	}
	public String getName() {
		return name;
	}
	public String getGender() {
		return gender;
	}
	public String getCity() {
		return city;
	}
	@Override
	public String toString() {
		return "UserVO [id=" + id + ", UserId=" + UserId + ", name=" + name + ", gender=" + gender + ", city=" + city
				+ "]";
	}
	
	
}
