package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import vo.UserVO;

public class UserDAO {
	private Connection connection;
	
	public UserDAO(String driverClass, String url, String username, String password) {		
		// 1. Driver class Loading (1���� ���� �ʿ�)
		try {
			Class.forName(driverClass);
			
			// 2. DB�� ������ ����ϴ� Connection ��ü ���� 
			connection = DriverManager.getConnection(url, username, password);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void connectionClose() { // // connection�� close �ʿ� 
		try {
			if (connection != null) connection.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	// where ���� ��ȸ 
	public UserVO getUser(String userId) {
		PreparedStatement pStmt = null;
		UserVO userVO = null;
		
		String sql = "select * from users where userid = ?";
		
		// 3. SQL���� DB���� �������ִ� ������ �ϴ� Statement ���� 
		try {
			pStmt = connection.prepareStatement(sql);
			pStmt.setString(1,  userId);
			
			ResultSet rs = pStmt.executeQuery();
			if (rs.next()) {
				userVO = new UserVO(rs.getInt("id"), 
								rs.getString("userId"), 
								rs.getString("name"), 
								rs.getString("gender"),
								rs.getString("city"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (pStmt != null) pStmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return userVO;
	}
	
	// ��� ��ȸ 
	public List<UserVO> getUserList() {
		PreparedStatement pStmt = null;
		List<UserVO> userList = new ArrayList<>();
		
		String sql = "select * from users order by id";

		try {
			pStmt = connection.prepareStatement(sql);
			
			ResultSet rs = pStmt.executeQuery();
			while (rs.next()) {
				UserVO userVO = new UserVO(rs.getInt("id"), 
								rs.getString("userId"), 
								rs.getString("name"), 
								rs.getString("gender"),
								rs.getString("city"));
				userList.add(userVO);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (pStmt != null) pStmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return userList;
	}
}
