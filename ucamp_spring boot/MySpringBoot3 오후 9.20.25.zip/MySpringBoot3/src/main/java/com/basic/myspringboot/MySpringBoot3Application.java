package com.basic.myspringboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MySpringBoot3Application {

	public static void main(String[] args) {
		SpringApplication.run(MySpringBoot3Application.class, args);
	}

}
