package com.basic.myspringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MySpringBoot3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
